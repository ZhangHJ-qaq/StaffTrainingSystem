package com.huajuan.stafftrainingsystembackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StaffTrainingSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(StaffTrainingSystemApplication.class, args);
    }

}
