package com.huajuan.stafftrainingsystembackend.repository;

import com.huajuan.stafftrainingsystembackend.entity.Teach;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeachRepository extends JpaRepository<Teach,String> {
}
