package com.huajuan.stafftrainingsystembackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDeemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
